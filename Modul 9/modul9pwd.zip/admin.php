<html>
<head>
    <title>Selamat Datang Admin</title>
    <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>
    <br>
    <center><h1>Selamat Datang Admin</h1>
    Silahkan logout dengan klik link <a href="logout2.php" class="link">Disini</a></center>
</body>
</html>